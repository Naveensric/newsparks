package pack

import org.apache.spark.SparkContext  // rdd
import org.apache.spark.sql.SparkSession  // dataframe
import org.apache.spark.SparkConf
import org.apache.spark.sql._

object objAwsDSL {


	def main(args:Array[String]):Unit={


			val conf = new SparkConf().setMaster("local[*]").setAppName("first")
					.set("fs.s3a.access.key","AKIASSGV4N5GIVX6MPVE")
					.set("fs.s3a.secret.key","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")



					val sc = new SparkContext(conf)
					sc.setLogLevel("ERROR")

					val spark = SparkSession.builder.config(conf).getOrCreate()

					import spark.implicits._

					
					
					val df = spark
					.read
					.format("json")
					.load("s3a://zdevb/cashdata")	

					df.show()


					val finaldf = df.filter("category='Team Sports'")


					finaldf.show()




	}
}