package pack

import org.apache.spark.SparkContext  // rdd
import org.apache.spark.sql.SparkSession  // dataframe
import org.apache.spark.SparkConf
import org.apache.spark.sql._
import org.apache.spark.sql.types._
import org.apache.spark.sql.functions._

object objDtData {


	def main(args:Array[String]):Unit={


			val conf = new SparkConf().setMaster("local[*]").setAppName("first")

			          
					val sc = new SparkContext(conf)
					sc.setLogLevel("ERROR")


					val spark = SparkSession.builder.config(conf).getOrCreate()

					import spark.implicits._

					
					val df = spark
					          .read
					          .format("csv")
					          .option("header","true")
					          .load("file:///C:/data/dt.txt") 
					
					df.show()
					
					//Task 1 ---
						println("##############Task 1 ##############")
					df.createOrReplaceTempView("tdf")
					 
					val df1= spark.sql("select *,case when spendby='cash' then 1 else 0 end as status from tdf")
					
					df1.show()
					
					
					
					// Task 2 
					
						println("############## Task 2 ##############")
					val df2 = spark.sql("select category,sum(amount) as total from tdf group by category order by category")
					
					df2.show()
					
					
					// Task 3 
					
					println("##############-Task 3##############")
					
					
					val df3 = spark.sql("select id,split(tdate,'-')[2] as year,amount,category,product,spendby from tdf")
					
					df3.show()
					
					
					
				  // Task 4  
					
					println("############## Task 4##############")
					
					
			   val df4= df.dropDuplicates("category")
					
			   
			   df4.show()
					
				
					
	}
}